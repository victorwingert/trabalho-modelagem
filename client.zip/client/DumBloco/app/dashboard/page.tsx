import { DashboardLayout } from "../../src/components/dashboard-layout"

export default function DashboardPage() {
  return <DashboardLayout />
}
